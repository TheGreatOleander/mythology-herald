# Mythology Herald v0.2

Consumes `episode_bundle` and `media_bundle` to produce a richer `promo_bundle`.

Run:
python herald.py
